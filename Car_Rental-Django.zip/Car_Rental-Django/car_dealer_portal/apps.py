from django.apps import AppConfig


class CarDealerPortalConfig(AppConfig):
    name = 'car_dealer_portal'
